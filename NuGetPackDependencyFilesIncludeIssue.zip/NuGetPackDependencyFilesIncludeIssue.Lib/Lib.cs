﻿using System;

namespace NuGetPackDependencyFilesIncludeIssue.Lib
{
  public class Lib
  {
    public void M ()
    {
      Console.WriteLine (typeof (Dependency.Dependency));
    }
  }
}