﻿using System;

namespace NuGetPackDependencyFilesIncludeIssue.Dependency
{
  public class Dependency
  {
  }
}